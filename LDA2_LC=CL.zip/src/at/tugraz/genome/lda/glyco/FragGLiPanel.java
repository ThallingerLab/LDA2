package at.tugraz.genome.lda.glyco;

import javax.swing.JPanel;

public class FragGLiPanel extends JPanel
{

}
