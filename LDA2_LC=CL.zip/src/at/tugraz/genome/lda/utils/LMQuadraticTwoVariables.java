/* 
 * This file is part of Lipid Data Analyzer
 * Lipid Data Analyzer - Automated annotation of lipid species and their molecular structures in high-throughput data from tandem mass spectrometry
 * Copyright (c) 2017 Juergen Hartler, Andreas Ziegl, Gerhard G. Thallinger, Leonida M. Lamp
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS FILE HEADER. 
 *  
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * by the Free Software Foundation, either version 3 of the License, or 
 * (at your option) any later version.
 *  
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details. 
 *  
 * You should have received a copy of the GNU General Public License 
 * along with this program. If not, see <http://www.gnu.org/licenses/>.
 *
 * Please contact lda@genome.tugraz.at if you need additional information or 
 * have any questions.
 */

package at.tugraz.genome.lda.utils;

import at.tugraz.genome.lda.exception.LMException;
import at.tugraz.genome.util.FloatMatrix;

/**
 * Implements the LevenbergMarquardtOptimizer for a quadratic function for two parameters
 * f(x,y) = A*x^2 + B*x + C*x^2 + D*x +E
 * @author Juergen Hartler
 *
 */
public class LMQuadraticTwoVariables extends LevenbergMarquardtOptimizer
{

  /** the values of the input parameters (a m x 2 matrix)*/
  private float[][] values_;
  /** the vector of equation results (a m x 1 matrix) */
  private float[][] observations_;
  
  /**
   * constructor setting the input values and the measured observations
   * @param values the values of the input parameters (a m x n matrix)
   * @param observations the measured results for the input values
   * @param parameters proposed starting parameters
   */
  public LMQuadraticTwoVariables(float[][] xValues, float[] observations, FloatMatrix parameters){
    values_ = xValues;
    observations_ = new float[observations.length][1];
    for (int i=0; i!=observations.length;i++){
      observations_[i][0] = observations[i];
    }
    if (parameters!=null) resultParams_ = parameters;
  }
  
  public void fit() throws LMException{
    float[][] parameters = null;
    if (this.values_.length<6) throw new LMException("There are too less observations for a model fit!");
    if (resultParams_ == null){
      parameters = new float[6][1];
      parameters[0][0] = 10f;
      parameters[1][0] = 0.1f;
      parameters[2][0] = -1f;
      parameters[3][0] = -10f;
      parameters[4][0] = 1f;
      parameters[5][0] = 1f;
    } else parameters = resultParams_.A;
    fit(parameters);
  }
  
  protected FloatMatrix calculateEquationResults(float[][] values,
      FloatMatrix paramsVector)
  {
    float[][] results = new float[values.length][1];
    for (int i=0;i!=values.length;i++){
      float equationResult = ((float)Math.pow(values[i][0],2d))*paramsVector.A[0][0];
      equationResult += values[i][0]*paramsVector.A[1][0];
      equationResult += (float)Math.pow(values[i][1],2d)*paramsVector.A[2][0];
      equationResult += values[i][1]*paramsVector.A[3][0];
      equationResult += values[i][0]*values[i][1]*paramsVector.A[4][0];
      equationResult += paramsVector.A[5][0];
      results[i][0] = equationResult;
    }
    return new FloatMatrix(results);
  }

  protected FloatMatrix calculateJacobianMatrix(float[][] values,
      float[][] parameters)
  {
    float[][] jacobian = new float[values.length][6];
    for (int i=0; i!=values.length; i++){
      jacobian[i][0] = (float)Math.pow(values[i][0],2d);
      jacobian[i][1] = values[i][0];
      jacobian[i][2] = (float)Math.pow(values[i][1],2d);
      jacobian[i][3] = values[i][1];
      jacobian[i][4] = values[i][0]*values[i][1];      
      jacobian[i][5] = 1f;
    }
    return new FloatMatrix(jacobian);
  }

  public float calculateFitValue(float[] input) throws LMException
  {
    if (input.length!=2) throw new LMException("The input must consist of two variables");
    float[][] values = new float[1][2];
    values[0][0] = input[0];
    values[0][1] = input[1];
    float result = calculateEquationResults(values, resultParams_).A[0][0];
    return result;
  }
  
  protected float[][] getValues(){
    return values_;
  }
  
  protected float[][] getObservations(){
    return observations_;
  }
}
