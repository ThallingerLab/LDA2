java  -Xms256m -Xmx1024m -Djava.ext.dirs=toInstall -jar toInstall/LipidDataAnalyzer.jar
